﻿using Libs.Entity;
using Libs.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System.Collections.Generic;

namespace WebApplication1.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class DemoController : ControllerBase
    {
        private ProductService productService;

        public DemoController(ProductService productService) {
            this.productService = productService;
        }
        [HttpGet("get-product")]
        public IActionResult getProductList() {
            List<Product> productList = productService.getProductList();
            return Ok(new { status = true, message = "", data = productList });
        }
    }
}
