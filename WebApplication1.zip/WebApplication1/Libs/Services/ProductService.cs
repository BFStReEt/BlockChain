﻿using Libs.Entity;
using Libs.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libs.Services
{
    public class ProductService
    {
        private ApplicationDbContext dbContext;
        private IProductRespository productRepository;

        public ProductService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
            this.productRepository = new ProductRespository(dbContext);
        }
        void Save() {
            dbContext.SaveChanges();
        }

        public List<Product> getProductList() { 
            return dbContext.Product.ToList();
        }
        public void insertProduct(Product product) {
            productRepository.insertProduct(product);
            Save();
        }

    }
}
