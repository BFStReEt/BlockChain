﻿using Lib.Data;
using Libs.Data;
using Libs.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libs.Repository
{
    public interface IProductRespository : IRepository<Product>
    {
        public void insertProduct(Product product);
    }
    public class ProductRespository : RepositoryBase<Product>, IProductRespository
    {
        public ProductRespository(ApplicationDbContext dbContext)
           : base(dbContext)
        {

        }
       
        public void insertProduct(Product product)
        {
            _dbcontext.Product.Add(product);
        }



    }
}
